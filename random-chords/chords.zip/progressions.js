const all_progressions_string = 
`
    ii° V7 i7
    ii° vi i7
    ii V7 I
    I III IV iv
    vi IV I V
`;